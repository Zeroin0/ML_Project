from django.contrib import admin
from list.models import pillInfo, search

# Register your models here.

admin.site.register(pillInfo)
admin.site.register(search)