from django.contrib import admin
from accounts.models import MEMBERS

# Register your models here.

admin.site.register(MEMBERS)